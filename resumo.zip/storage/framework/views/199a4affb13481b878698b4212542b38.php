<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Celke')); ?></title>

    </head>
    <body>
        <h3>Bem-vindo à Celke!</h3>
    </body>
</html>
<?php /**PATH C:\celke\celke\resources\views/welcome.blade.php ENDPATH**/ ?>