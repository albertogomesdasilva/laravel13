<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>{{ config('app.name', 'Celke') }}</title>

    </head>
    <body>
        <h3>Bem-vindo à Celke!</h3>
    </body>
</html>
