- Projeto desenvolvido no Curso de Laravel 13.

## Requisitos

* PHP 8.3 ou superior - Conferir a versão: php -v
* MySQL 8 ou superior - Conferir a versão: mysql --version
* Composer - Conferir a instalação: composer --version
* Node.js 24 ou superior - Conferir a versão: node -v



## Preparar o Ambiente

Instalar o PHP.
```
winget install PHP.PHP.8.3
```

Instalar o MySQL Community.
```
https://dev.mysql.com/downloads/mysql/8.4.html
```
```
winget install Oracle.MySQL
```

Baixar o Composer.
```
https://getcomposer.org/download/
```

Baixar o Node.js.
```
https://nodejs.org/pt-br/download
```

## Como rodar o projeto baixado


## Sequência para criar o projeto

Instalar o Laravel no computador.
```
composer global require laravel/installer
```

Criar o projeto com Laravel. A palavra "celke" no final indica o nome do diretório que será criado, e dentro dele o projeto será instalado.
```
laravel new celke
```

Ativar unzip no php.ini.
```
C:\Users\cesar\AppData\Local\Microsoft\WinGet\Packages\...
extension=zip
```

- Which starter kit would you like to install? [None] - Qual starter kit você gostaria de instalar? [Nenhum] - Digite none para selecionar a opção "Nenhum".
- Which testing framework do you prefer? [Pest] -  Qual framework de testes você prefere? [Pest] - Digite 0 para selecionar a opção "Pest".
- Do you want to install Laravel Boost to improve AI assisted coding? (yes/no) [yes] - Você deseja instalar o Laravel Boost para melhorar a programação assistida por IA? (sim/não) [sim] - Digite não para criar o ambiente mais simples.
- Which database will your application use? [SQLite (Missing PDO extension)] - Qual banco de dados sua aplicação irá utilizar? [SQLite (Extensão PDO ausente)] - Digite mysql para selecionar a opção "MySQL".
- Default database updated. Would you like to run the default database migrations? (yes/no) [yes] - Banco de dados padrão atualizado. Deseja executar as migrações do banco de dados padrão? (sim/não) [sim] - Digite no para não executar as migrations.
- Would you like to run npm install and npm run build? (yes/no) [yes] - Deseja executar npm install e npm run build? (sim/não) [sim] - Digite yes para executar.

Ativar as extensões no php.ini.
```
C:\Users\cesar\AppData\Local\Microsoft\WinGet\Packages\
extension=fileinfo
ou
extension=php_fileinfo.dll
```

- Comentar as credenciais do banco de dados.
```
# DB_CONNECTION=mysql
# DB_HOST=127.0.0.1
# DB_PORT=3306
# DB_DATABASE=celke
# DB_USERNAME=root
# DB_PASSWORD=
```

Alterar para armazenar as sessões no arquivo "file" para fazer o teste sem o banco de dados.
```
# SESSION_DRIVER=file
```

Acessar o diretório do projeto.
```
cd celke
```

Rodar o projeto local.
```
composer run dev
```

## Autor

Este projeto foi desenvolvido por [Cesar Szpak](https://github.com/cesarszpak) e está hospedado no repositório da organização [Celke](https://github.com/celkecursos).

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo [LICENSE](LICENSE.txt) para mais detalhes.